print(7 + 3)     # 10
print(7 - 3)     # 4
print(7 * 3)     # 21
print(7 / 3)     # 2.333...
print(7 // 3)    # 2
print(7 % 3)     # 1
print(7 ** 3)    # 343
print(2 + 3 * 4 ** 2)  # 50
